package bg.sofia.uni.fmi.splitwise;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

public class Server {
	private static final int PORT = 8080;
	private ServerSocket serverSocket;

	private File dataBase;
	private ConcurrentHashMap<String, UserInfo> users;
	private ConcurrentHashMap<String, HashMap<String, Double>> groups;
	private ConcurrentHashMap<String, HashMap<String, ArrayList<String>>> offlineUsers;
	private ConcurrentHashMap<String, File> paymentHistory;
	private File errors;

	Server(ServerSocket serverSocket) {
		this.serverSocket = serverSocket;
		dataBase = new File("resources/DataBase.txt");
		users = new ConcurrentHashMap<>();
		groups = new ConcurrentHashMap<>();
		offlineUsers = new ConcurrentHashMap<>();
		paymentHistory = new ConcurrentHashMap<>();
		errors = new File("resources/Errors.txt");
	}

	public static void main(String[] args) {
		try {
			new Server(new ServerSocket(PORT)).run();		
		} catch (IOException e) {
			System.out.println("A problem occured in the server!");
		}
	}
	
	private void run() {
		System.out.println("The server is running");
		restoreUserInformation();
		while (true) {
			try {
				new Thread(new UserConnectionRunnable(serverSocket.accept(), this)).start();
			} catch (IOException e) {
				System.out.println("A problem occured in the server!");
				registerError(e.getMessage());
			}
		}
	}

	public ConcurrentHashMap<String, UserInfo> getUsers() {
		synchronized (users) {
			return users;
		}
	}

	public UserInfo getUser(String username) {
		synchronized (users) {
			return users.get(username);
		}
	}

	public Map<String, Double> getUsersInTheGroup(String group) {
		synchronized (groups) {
			return groups.get(group);
		}
	}

	public synchronized HashMap<String, ArrayList<String>> getNotification(String user) {
		HashMap<String, ArrayList<String>> notification = offlineUsers.get(user);
		offlineUsers.remove(user);
		return notification;
	}

	public boolean isUserExisting(String username) {
		synchronized (users) {
			return users.containsKey(username);
		}
	}

	public boolean isGroupExisting(String group) {
		synchronized (groups) {
			return groups.containsKey(group);
		}
	}

	public void registerUser(String username, UserInfo user) {
		synchronized (users) {
			try {
				users.put(username, user);
				paymentHistory.put(username, new File("resources/" + username + ".txt"));
				PrintWriter userWriter = new PrintWriter(new FileWriter(dataBase, true));
				JsonObject json = new JsonObject();
				json.addProperty("username", user.getUsername());
				json.addProperty("password", user.getPassword());
				json.addProperty("name", user.getName());
				json.addProperty("surname", user.getSurname());
				userWriter.println(json);
			} catch (IOException e) {
				System.out.println("There is a problem with registering the user in the server!");
				registerError(e.getMessage());
			}
		}
	}

	public void updateGroupSum(String group, String username, Double sum) {
		synchronized (groups) {
			groups.get(group).put(username, sum);
		}
	}

	public void createGroup(String group, HashMap<String, Double> users) {
		synchronized (groups) {
			groups.put(group, users);
		}
	}

	public void logoutUser(String user, HashMap<String, ArrayList<String>> notification) {
		synchronized (offlineUsers) {
			offlineUsers.put(user, notification);
		}
	}

	public void makeNotificationForOfflineUsers(String user, String message, String from) {
		synchronized (offlineUsers) {
			if (offlineUsers.containsKey(user)) {
				offlineUsers.get(user).get(from).add(message);
			}
		}
	}

	public synchronized void registerPayment(String user, String payment) {
		try {
			PrintWriter paymentWriter = new PrintWriter(
					new FileWriter(paymentHistory.get(user).getAbsolutePath(), true));
			paymentWriter.println(payment);
			paymentWriter.close();
		} catch (IOException e) {
			System.out.println("There is a problem while entering payment in user's paymentHistory file!");
			registerError(e.getMessage());
		}
	}

	public synchronized void registerError(String stackTrace) {
		try {
			PrintWriter errorsWriter = new PrintWriter(new FileWriter(errors.getAbsolutePath(), true));
			errorsWriter.println(stackTrace);
			errorsWriter.close();
		} catch (IOException e) {
			System.out.println("There was a problem while registerig the user!");
			registerError(e.getMessage());
		}
	}

	private void restoreUserInformation() {
		try {
			BufferedReader userReader = new BufferedReader(new FileReader(dataBase));
			String userInfo = userReader.readLine();
			Gson gson = new GsonBuilder().create();
			while (userInfo != null) {
				UserInfo user = gson.fromJson(userInfo, UserInfo.class);
				users.put(user.getUsername(), user);
				userInfo = userReader.readLine();
			}
		} catch (FileNotFoundException e) {
			System.out.println("There is a problem with the dataBase!");
			registerError(e.getMessage());
		} catch (IOException e) {
			System.out.println("There is a problem with restorig the user information!");
			registerError(e.getMessage());
		}

	}

}
