package bg.sofia.uni.fmi.splitwise;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class UserConnectionRunnable implements Runnable {

	private String username;
	private String password;
	private Socket socket;
	private BufferedReader reader;
	private PrintWriter writer;
	private Server server;

	private final int FIRST_ARGUMENT = 0;
	private final int SECOND_ARGUMENT = 1;
	private final int THIRD_ARGUMENT = 2;
	private final int FOURTH_ARGUMENT = 3;
	private final Double INITIAL_SUM = 0.0;
	private final int NUMBER_OF_FRIENDS = 2;
	private final int NUMBER_OF_ARGUMENTS = 2;
	private final int NUMBER_OF_COMMAND_ARGUMENTS = 4;

	public UserConnectionRunnable(Socket socket, Server server) {
		this.socket = socket;
		this.server = server;
	}

	@Override
	public void run() {
		try {
			writer = new PrintWriter(socket.getOutputStream(), true);
			reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

			String command = reader.readLine();
			connect(command);

			while (true) {
				writer.println("Enter command: ");
				command = reader.readLine();

				if (command.startsWith("logout")) {
					writer.println("Disconnect user " + getUserInfo(username));
					logout();
					return;
				}

				executeTheCommand(command);
			}
		} catch (IOException e) {
			System.out.println("Error in the userConnection while executing the commands!");
			server.registerError(e.getMessage());
		} finally {
			try {
				socket.close();
				writer.close();
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private void connect(String command) {
		try {
			writer.println("Enter username and password: ");
			while (true) {
				String in = reader.readLine();
				if (in == null) {
					writer.println("Wrong entered credentials! Enter again!");
					continue;
				}

				String[] credentials = in.split(" ");
				if (credentials.length != NUMBER_OF_ARGUMENTS) {
					writer.println("Wrong entered credentials! Enter again!");
					continue;
				}

				username = credentials[FIRST_ARGUMENT];
				password = credentials[SECOND_ARGUMENT];

				synchronized (server.getUsers()) {
					if (command.equals("login")) {
						if (!server.isUserExisting(username)) {
							writer.println("This username: " + username + " doesn't exist! Enter again!");
						} else if (!server.getUser(username).isPasswordCorrect(password)) {
							writer.println("Wrong password! Enter username and password again!");
						} else {
							writer.println("Successfully login!");
							getNotification();
							break;
						}
					} else {
						if (server.isUserExisting(username)) {
							writer.println("This username: " + username + " already exist! Enter again!");
						} else {
							writer.println("Add name and surname: ");
							command = reader.readLine();
							String[] names = command.split(" ");
							String name = names[FIRST_ARGUMENT];
							String surname = names[SECOND_ARGUMENT];
							UserInfo user = new UserInfo(username, password, name, surname);
							server.registerUser(username, user);
							writer.println("Successfully registered user: " + getUserInfo(username));
							break;
						}
					}
				}
			}
		} catch (IOException e) {
			System.out.println("Problem while login! Try again later!");
			server.registerError(e.getMessage());
		}
	}

	private void executeTheCommand(String commandInput) {
		String[] input = commandInput.split(" ");
		String command = input[FIRST_ARGUMENT];

		if (command.equals("add-friend")) {
			addFriend(input);
		} else if (command.equals("create-group")) {
			createGroup(input);
		} else if (command.equals("split")) {
			split(input);
		} else if (command.equals("split-group")) {
			splitGroup(input);
		} else if (command.equals("get-status")) {
			getStatus();
		} else if (command.equals("payed")) {
			payed(input);
		} else if (command.equals("help")) {
			help();
		} else {
			writer.println("Wrong command! Try again!");
		}
	}

	private void addFriend(String[] input) {
		if (input.length != NUMBER_OF_ARGUMENTS) {
			writer.println("Wrong command! You have to write add-friend friends_name!");
			return;
		}
		String friend = input[SECOND_ARGUMENT];
		if (!server.isUserExisting(friend)) {
			writer.println("This user doesn't extist: " + friend);
			return;
		}
		server.getUser(username).addFriend(friend);
		server.getUser(friend).addFriend(username);
		writer.println("User " + username + " is now friend with " + getUserInfo(friend));
	}

	private void createGroup(String[] input) {
		if (input.length < NUMBER_OF_COMMAND_ARGUMENTS) {
			writer.println("Wrong command! You have written less than 4 words!");
			return;
		}
		String group = input[SECOND_ARGUMENT];
		server.getUser(username).addGroup(group);
		HashMap<String, Double> groupMembers = new HashMap<>();
		groupMembers.put(username, INITIAL_SUM);
		for (int i = THIRD_ARGUMENT; i < input.length; i++) {
			groupMembers.put(input[i], INITIAL_SUM);
			server.getUser(input[i]).addGroup(group);
		}
		server.createGroup(group, groupMembers);
		writer.println("Created group " + group);
	}

	private void split(String[] input) {
		if (input.length < NUMBER_OF_COMMAND_ARGUMENTS) {
			writer.println("Wrong command! You have writen less than 3 arguments!");
			return;
		}
		Double sum = Double.parseDouble(input[SECOND_ARGUMENT]) / NUMBER_OF_FRIENDS;
		String friend = input[THIRD_ARGUMENT];
		if (!server.isUserExisting(friend)) {
			writer.println("User " + friend + " doesn't exist!");
			return;
		}
		server.getUser(username).updateSum(sum, friend);
		server.getUser(friend).updateSum(-sum, username);
		String message = "Splited " + sum * NUMBER_OF_FRIENDS + " lv between you and " + getUserInfo(friend);
		writer.println(message);
		server.registerPayment(username, message);
		makeNotification(input);
		currentStatus(friend, server.getUser(username).getFriendsSum(friend));
	}

	private void splitGroup(String[] input) {
		if (input.length < NUMBER_OF_COMMAND_ARGUMENTS) {
			writer.println("Wrong command! You have writen less than 3 arguments!");
			return;
		}
		String group = input[THIRD_ARGUMENT];
		if (!server.isGroupExisting(group)) {
			writer.println("Group " + group + " doesn't exist!");
			return;
		}
		Double sum = Double.parseDouble(input[SECOND_ARGUMENT]);
		int numberOfMembersInTheGroup = server.getUsersInTheGroup(group).size();
		String message = "Splited " + sum + " between you and the members in the group " + group;
		for (String user : server.getUsersInTheGroup(group).keySet()) {
			Double newSum = INITIAL_SUM;
			if (user.equals(username)) {
				newSum = server.getUsersInTheGroup(group).get(user) - sum + (sum / numberOfMembersInTheGroup);
			} else {
				newSum = server.getUsersInTheGroup(group).get(user) + (sum / numberOfMembersInTheGroup);
			}
			server.updateGroupSum(group, user, newSum);
			server.registerPayment(username, message);
		}
		makeNotification(input);
		writer.println(message);
	}

	private void payed(String[] input) {
		if (input.length < NUMBER_OF_COMMAND_ARGUMENTS) {
			writer.println("Wrong command! You have writen less than 3 arguments!");
			return;
		}
		String friend = input[THIRD_ARGUMENT];
		Double sum = Double.parseDouble(input[SECOND_ARGUMENT]);
		if (!server.isUserExisting(friend)) {
			writer.println("User " + friend + " doesn't exist!");
			return;
		}
		server.getUser(username).updateSum(-sum, friend);
		server.getUser(friend).updateSum(sum, username);
		writer.println(getUserInfo(friend) + " payed you " + sum + " lv");
		makeNotification(input);
		currentStatus(friend, server.getUser(username).getFriendsSum(friend));
	}

	private void getStatus() {
		writer.println("Friends:");
		for (String user : server.getUser(username).getFriends()) {
			double sum = server.getUser(username).getFriendsSum(user);
			currentStatus(user, sum);
		}

		writer.println("\nGroups:");
		for (String group : server.getUser(username).getGroups()) {
			writer.println(group);
			for (String user : server.getUsersInTheGroup(group).keySet()) {
				if (!user.equals(username)) {
					int members = server.getUsersInTheGroup(group).size();
					double sum = server.getUsersInTheGroup(group).get(user);
					currentStatus(user, sum / members);
				}
			}
		}
	}

	private void help() {
		writer.println(
				"Possible commands:\nadd-friend \ncreate-group \nsplit \nsplit-group \nget-status \npayed \nhelp");
	}

	private void currentStatus(String user, double sum) {
		if (sum > INITIAL_SUM) {
			writer.println(getUserInfo(user) + ": Owes you " + sum + " lv");
		} else if (sum < INITIAL_SUM) {
			sum = -sum;
			writer.println(getUserInfo(user) + ": You owe " + sum + " lv");
		} else {
			writer.println(getUserInfo(user) + ": Owes you nothing");
		}
	}

	private void getNotification() {
		HashMap<String, ArrayList<String>> notification = server.getNotification(username);
		writer.println("Friends:");
		for (String message : notification.get("friends")) {
			writer.println(message);
		}
		writer.println("\nGroups:");
		for (String message : notification.get("groups")) {
			writer.println(message);
		}
	}

	private void makeNotification(String[] input) {
		String command = input[FIRST_ARGUMENT];
		String sum = input[SECOND_ARGUMENT];
		String name = input[THIRD_ARGUMENT];
		String[] purpose = Arrays.copyOfRange(input, FOURTH_ARGUMENT, input.length);
		String message;
		switch (command) {
		case "split":
			message = username + " payed " + sum + " lv [" + String.join(" ", purpose) + "].";
			server.makeNotificationForOfflineUsers(name, message, "friends");
			break;
		case "split-group":
			int membersInGroup = server.getUsersInTheGroup(name).size();
			message = "You owe " + username + " " + Double.parseDouble(sum) / membersInGroup + " lv ["
					+ String.join(" ", purpose) + "].";
			for (String user : server.getUsersInTheGroup(name).keySet()) {
				server.makeNotificationForOfflineUsers(user, message, "groups");
			}
			break;
		case "payed":
			message = username + " approved your payment " + sum + " lv [" + String.join(" ", purpose) + "].";
			server.makeNotificationForOfflineUsers(name, message, "friends");
			break;
		default:
			break;
		}
	}

	private void logout() {
		HashMap<String, ArrayList<String>> notification = new HashMap<>();
		notification.put("friends", new ArrayList<>());
		notification.put("groups", new ArrayList<>());
		server.logoutUser(username, notification);
	}

	public String getUserInfo(String username) {
		UserInfo user = server.getUser(username);
		String info = user.getName() + " " + user.getSurname() + " (" + username + ")";
		return info;
	}
}
