package bg.sofia.uni.fmi.splitwise;


public class ServerTest {
	
	
	
}
